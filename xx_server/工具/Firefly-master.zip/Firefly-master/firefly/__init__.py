#coding:utf8
'''
Created on 2013-10-21

@author: lan (www.9miao.com)
'''


from firefly._version import version
__version__ = version.short()